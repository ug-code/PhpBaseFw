<?php 

		/**
		* @author 		ug-code
		* @since 		2016-08-30
		* @version      Simple Base Fw v1.0
		**/
define('TIME_START', microtime(true));
/*
|--------------------------------------------------------------------------
| Register The Composer Auto Loader
|--------------------------------------------------------------------------
|
| Composer provides a convenient, automatically generated class loader
| for our application. We just need to utilize it! We'll require it
| into the script here so we do not have to manually load any of
| our application's PHP classes. It just feels great to relax.
|
*/

$vendor_autoload =  __DIR__.'/vendor/autoload.php';
if (file_exists($vendor_autoload)) {
    require $vendor_autoload;
}

#install Framework	
require __DIR__.'/config/config.global.php';

//require library's _helpers.php
require __DIR__ . '/Library/Helpers/_helpers.php';

//require route
require __DIR__ . '/app/route.php';




