<?php
	
	/**
	* @author 	ug-code
	* @since    2016-08-30 20:37
	* @modify   2016-09-21 19:19   
	*/

	# 00. Install
	//coming Soon

	# 01. INITIALIZE
	require('constants.php');		     #constant variable
	require('functions.global.php');	 #helper class and function
	require('database.php');             #Db connect
