<?php

	/*
    |--------------------------------------------------------------------------
    |  Default Database Connection 
    |--------------------------------------------------------------------------
    |  My Define Master db
    | 
    |
    */
		define("MASTER_HOSTNAME", "localhost");		#	Master Hostname/IP of Host
		define("MASTER_DATABASE", "dbname");	    #	Master Database
		define("MASTER_USERNAME", "root");			#	Master Username
		define("MASTER_PASSWORD", "");			    #	Master Password