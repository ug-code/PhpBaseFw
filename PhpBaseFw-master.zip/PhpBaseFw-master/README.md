# PhpBaseFw
Simple PHP framework

@author  : Ug-code<br>
@version : v1.0<br>
https://ug-code.github.io/PhpBaseFw/

### Turkish Note:
1-) Micro Mvc modu

2-) Diğer Frameworkler gibi kısıtlayıcı değildir.

3-) Amaç pure kod yazılmasında kolaylık sağlanması.

4-) Düzenli kod yazımı.

5-) Full Path ayarlanması. https,http otomatik algılama sistemi.

6-) Asset klasöründeki(css,js,img) vb. dosyalar için Tam yol url path ayarlaması.

7-) Kendi Constant'ları ekleyebileceginiz Dosya("Config/constants.php")

8-) Düzenli Not tutma alanı ("/_note") klasörü içindeki Default dökümantasyon bulunmakta.

9-) (" _test") Ufak class,function'ları test edebileceginiz alandır.Tek yapılması gereken Config.globası dahil etmeniz ve keyfinize bakmanız.

10-) Düzenli Klasörleme yapısı. Herhangi bir kodlama yapısı öğrenmek zorunda kalmadan direk uygulama

### İkinci Version Düşünülenler
1-) Insert,Update,Delete auto triger ve otomatik json çıktısı.
2-) Veritabanı yerine jsondan Otomatik listeleme.
3-) Js Pathleme sistemi.


