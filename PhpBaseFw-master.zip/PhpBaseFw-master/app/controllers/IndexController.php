<?php
	/*
    |--------------------------------------------------------------------------
    |  Default  Controller 
    |--------------------------------------------------------------------------
    |  My First Controller
    | 
    |
    */
   
namespace App\Controllers;

use App\Core\Controller;

class IndexController  extends Controller
{
    public function index()
    {
       echo "ben geldim";
    }
}