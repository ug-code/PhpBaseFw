<?php
	/*
    |--------------------------------------------------------------------------
    |  Default  Controller 
    |--------------------------------------------------------------------------
    |  My First Controller
    | 
    |
    */
   
namespace App\Controllers;

//use Symfony\Component\HttpFoundation\Response;
use App\Core\Controller;

class TestController extends Controller
{
    public function test($parameter)
    {
       echo "ben geldim test";
    }
}