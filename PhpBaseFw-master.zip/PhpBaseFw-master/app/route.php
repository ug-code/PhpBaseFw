<?php

// config/routes.php
use \App\Core\URLPrettifier;
$site = $_SERVER["HTTP_HOST"];



$url 			= new URLPrettifier($site);

$content_link	= is_empty($url->segment(2)) ? $url->segment(2) : "Index";

$controller = "\\App\\Controllers\\".$content_link."Controller";
$init  =  new $controller();

$init->index();


