<?php

namespace App\Core;



class Controller 
{
    public function index()
    {
      
    }
}