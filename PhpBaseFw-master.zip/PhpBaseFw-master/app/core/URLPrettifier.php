<?php

namespace App\Core;
/*
** CLEAN URLs
*/

class URLPrettifier {

	var $site_path;

	public function __construct($site_path){
		$this->site_path = $this->removeSlash($site_path);
	}

	public function __toString(){
		return $this->site_path;
	}

	private function removeSlash($string){
		if($string[strlen($string)-1] == '/')
			$string = rtrim($string, '/');
		return $string;
	}

	public function segmentCount($segment=null){
		$url = str_replace($this->site_path, '', $_SERVER["REQUEST_URI"]);
		$url = explode('/', $url);
		return is_null($segment) ? count($url) : $url;

		/*
		if(is_null($segment))
			return count($url);
		else
			return $url;
		*/
	}

	public function segment($segment){
		$url = $this->segmentCount($segment);
		return isset($url[$segment]) ? $url[$segment] : false;

		/*
		if(isset($url[$segment]))
			return $url[$segment];
		else 
			return false;
		*/
	}

}