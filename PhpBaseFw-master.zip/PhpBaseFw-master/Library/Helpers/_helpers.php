<?php

/**
 * _helpers helper functions
 * @author fbulut
 * @copyright (c) 2015 Haziran Yazılım
 */

/** @return connected client ip, from Cloudflare if exists */
function get_client_ip() {
    if (isset($_SERVER["HTTP_CF_CONNECTING_IP"])) {
        return $_SERVER["HTTP_CF_CONNECTING_IP"];
    }
    return request()->getClientIp();
}

function is_admin() {
    return \Auth::user()->responsibility_id == \Config::get('auth.admin');
}

function has_module($module_name) {
    return in_array($module_name, \Config('feature.modules'));
}

if (!function_exists('file_upload_max_size')) {

    function file_upload_max_size($as = 'b') {
        static $max_size = -1;

        if ($max_size < 0) {
            // Start with post_max_size.
            $max_size = parse_size(ini_get('post_max_size'));

            // If upload_max_size is less, then reduce. Except if upload_max_size is
            // zero, which indicates no limit.
            $upload_max = parse_size(ini_get('upload_max_filesize'));
            if ($upload_max > 0 && $upload_max < $max_size) {
                $max_size = $upload_max;
            }
        }
        switch ($as) {
            case 'mb' : return ($max_size / 1024 / 1024) . " MB";
            case 'kb' : return ($max_size / 1024 ) . " KB";
            case 'b' :return ($max_size) . " bytes";
        }
        return $max_size;
    }

}
if (!function_exists('parse_size')) {

    function parse_size($size) {
        $unit = preg_replace('/[^bkmgtpezy]/i', '', $size); // Remove the non-unit characters from the size.
        $size = preg_replace('/[^0-9\.]/', '', $size); // Remove the non-numeric characters from the size.
        if ($unit) {
            // Find the position of the unit in the ordered string which is the power of magnitude to multiply a kilobyte by.
            return round($size * pow(1024, stripos('bkmgtpezy', $unit[0])));
        } else {
            return round($size);
        }
    }

}

if (!function_exists('e')) {

    $__tr_html_entities = [
        '&Uuml;', '&uuml;', '&Ouml;', '&ouml;', '&Ccedil;', '&ccedil;'
    ];
    $__tr_html_entities_flip = [
        'Ü', 'ü', 'Ö', 'ö', 'Ç', 'ç'
    ];

    /**
     * Override laravels escape for turkish charsets
     * Original in: ..\vendor\laravel\framework\src\Illuminate\Support\helpers.php */
    function e($value) {
        global $__tr_html_entities, $__tr_html_entities_flip;
        if ($value instanceof Htmlable) {
            return $value->toHtml();
        }

        $v = htmlentities($value, ENT_QUOTES, 'UTF-8', false);

        return str_replace($__tr_html_entities, $__tr_html_entities_flip, $v);
    }

}

if (!function_exists('apache_request_headers')) {

    //FatalErrorException in WSDLCreator.php line 111: Call to undefined function WSDL\apache_request_headers()
    //Nginx does not support this function. This is the counterpart function for nginx server
    //fbulut

    function apache_request_headers() {
        foreach ($_SERVER as $key => $value) {
            if (substr($key, 0, 5) == "HTTP_") {
                $key = str_replace(" ", "-", ucwords(strtolower(str_replace("_", " ", substr($key, 5)))));
                $out[$key] = $value;
            } else {
                $out[$key] = $value;
            }
        }
        return $out;
    }

}

if (!function_exists('sha256')) {

    function sha256($s) {
        return hash('sha256', $s);
    }

}
if (!function_exists('sha384')) {

    function sha384($s) {
        return hash('sha384', $s);
    }

}
if (!function_exists('sha512')) {

    function sha512($s) {
        return hash('sha512', $s);
    }

}

/**
 * Class casting
 *
 * @param string|object $destination
 * @param object $sourceObject
 * @return object */
function cast($destination, $sourceObject) {
    if (is_string($destination)) {
        $destination = new $destination();
    }
    $sourceReflection = new ReflectionObject($sourceObject);
    $destinationReflection = new ReflectionObject($destination);
    $sourceProperties = $sourceReflection->getProperties();
    foreach ($sourceProperties as $sourceProperty) {
        $sourceProperty->setAccessible(true);
        $name = $sourceProperty->getName();
        $value = $sourceProperty->getValue($sourceObject);
        if ($destinationReflection->hasProperty($name)) {
            $propDest = $destinationReflection->getProperty($name);
            $propDest->setAccessible(true);
            $propDest->setValue($destination, $value);
        } else {
            $destination->$name = $value;
        }
    }
    return $destination;
}

function to1d($arr) {
    if (!is_array($arr) || count($arr) < 1) {
        return [];
    }
    $ret = [];
    foreach ($arr as $ar) {
        $ret[] = current($ar);
    }
    return $ret;
}

function br2nl($s) {
    return preg_replace('#<br\s*/?>#i', "\n", $s);
}

function vd($data, $die = false) {
    var_dump($data);
    if ($die == true) {
        $msg = is_bool($die) ? null : $die;
        die($msg);
    }
}

function pr($data, $die = false) {
    print_r($data);
    if ($die == true) {
        $msg = is_bool($die) ? null : $die;
        die($msg);
    }
}

if (!function_exists('asfloat')) {

    function asfloat($str) {
        return floatval(str_replace(",", ".", $str));
    }

}